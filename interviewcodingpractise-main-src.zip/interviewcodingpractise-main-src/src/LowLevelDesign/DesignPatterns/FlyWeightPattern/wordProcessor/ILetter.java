package LowLevelDesign.DesignPatterns.FlyWeightPattern.wordProcessor;

public interface ILetter {

    public void display(int row, int column);
}
