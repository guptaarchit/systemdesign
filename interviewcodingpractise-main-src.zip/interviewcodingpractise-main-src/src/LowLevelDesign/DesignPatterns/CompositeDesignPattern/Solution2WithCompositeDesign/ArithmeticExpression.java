package LowLevelDesign.DesignPatterns.CompositeDesignPattern.Solution2WithCompositeDesign;

public interface ArithmeticExpression {

    public int evaluate();
}
