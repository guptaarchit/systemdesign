package LowLevelDesign.DesignBookMyShow.Enums;

public enum City {
    Bangalore,
    Delhi;
}
