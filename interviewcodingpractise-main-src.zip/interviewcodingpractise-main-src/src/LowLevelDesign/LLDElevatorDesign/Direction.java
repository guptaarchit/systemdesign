package LowLevelDesign.LLDElevatorDesign;

public enum Direction {
    UP,
    DOWN;
}
