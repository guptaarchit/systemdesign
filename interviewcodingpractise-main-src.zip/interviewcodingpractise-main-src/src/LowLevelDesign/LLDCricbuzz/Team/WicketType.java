package LowLevelDesign.LLDCricbuzz.Team;

public enum WicketType {

    RUNOUT,
    BOLD,
    CATCH;
}
