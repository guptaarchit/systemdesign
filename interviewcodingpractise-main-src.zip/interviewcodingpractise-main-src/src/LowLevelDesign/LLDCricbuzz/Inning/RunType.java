package LowLevelDesign.LLDCricbuzz.Inning;

public enum RunType {

    ZERO,
    ONE,
    TWO,
    THREE,
    FOUR,
    SIX;
}
