package LowLevelDesign.LLDCarRentalSystem;

public enum PaymentMode {

    CASH,
    ONLINE;
}
