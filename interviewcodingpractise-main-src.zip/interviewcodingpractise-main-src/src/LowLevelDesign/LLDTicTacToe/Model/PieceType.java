package LLDTicTacToe.Model;

public enum PieceType {
    X,
    O;
}
