package LLDTicTacToe.Model;

public class PlayingPieceO extends PlayingPiece{

    public PlayingPieceO() {
        super(PieceType.O);
    }
}
