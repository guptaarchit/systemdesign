package LLDTicTacToe.Model;

public class PlayingPieceX extends PlayingPiece{

    public PlayingPieceX() {
        super(PieceType.X);
    }
}
