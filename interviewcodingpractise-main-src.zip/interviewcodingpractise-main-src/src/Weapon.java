public class Weapon {

    String type;
}
