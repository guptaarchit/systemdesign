package dummy;

public abstract class  Test2 {

    public abstract void method1();
}
