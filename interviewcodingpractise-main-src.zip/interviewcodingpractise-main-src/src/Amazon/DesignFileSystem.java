package Amazon;
//https://www.youtube.com/watch?v=oXEPfYaMOwI
//https://leetcode.com/problems/design-in-memory-file-system/
public class DesignFileSystem {


}
